# Skincomparing
For the skin comparing application

https://trello.com/b/qMzeOfaz/firstbuild


## Running the app
We can run the app in development mode by pulling the repo and running

```docker-compose -f docker-compose-dev.yml up --build```

The frontend has hot reloading. For flask this can also be enabled in the future.
Currently this runs Postgress (for convenience)
